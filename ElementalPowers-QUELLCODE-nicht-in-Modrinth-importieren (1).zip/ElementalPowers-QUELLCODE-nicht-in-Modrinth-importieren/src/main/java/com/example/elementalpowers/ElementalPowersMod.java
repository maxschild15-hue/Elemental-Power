package com.example.elementalpowers;

import com.mojang.brigadier.Command;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * ELEMENTAL POWERS - Das ultimative Superkräfte-Handbuch
 * Forge für Minecraft 1.21.11 (Mojang-Mappings, EventBus 7)
 *
 * 7 Kräfte • 42 Fähigkeiten • unendliche Möglichkeiten (kein Cooldown, kein Mana)
 *
 * Befehle:
 *   /power <kraft> <fähigkeit>     z.B. /power feuer feuerball
 *   /power <kraft>                 listet die Fähigkeiten einer Kraft
 *   /power list                    listet alles
 *   /power clear                   schaltet alle Dauer-Effekte (Blitzschild, Flug) ab
 *
 * Kräfte: feuer, blitz, eis, schatten, wind, kosmos, natur
 */
@Mod(ElementalPowersMod.MOD_ID)
public class ElementalPowersMod {
    public static final String MOD_ID = "elementalpowers";

    // ------------------------------------------------------------------
    // Einstellungen
    // ------------------------------------------------------------------
    /** Dürfen Explosionen Blöcke zerstören? */
    static final boolean BLOCK_DAMAGE = true;
    /** Dauer von Debuffs auf Gegnern (Einfrieren usw.). -1 = unendlich ("auf Dauer"). */
    static final int DEBUFF_TICKS = 20 * 30;
    /** Wie lange Beschwörungen (Klon, Pflanzenwächter) bleiben. */
    static final int SUMMON_TICKS = 20 * 120;

    // ------------------------------------------------------------------
    // Datentypen
    // ------------------------------------------------------------------
    record Caster(ServerPlayer player, ServerLevel world) {
        Vec3 eye() { return player.getEyePosition(); }
        Vec3 look() { return player.getLookAngle(); }
        void msg(String s) { player.displayClientMessage(Component.literal(s), true); }
    }

    record Hit(Vec3 pos, LivingEntity entity) {}

    record Ability(String id, String name, String desc, Consumer<Caster> action) {}

    record Element(String id, String name, List<Ability> abilities) {}

    record Anchor(ResourceKey<Level> dim, Vec3 pos) {}

    @FunctionalInterface
    interface Tick { boolean run(int age); } // true = Task beenden

    private static final class Task {
        final Tick tick;
        final int max;
        int age;
        Task(Tick tick, int max) { this.tick = tick; this.max = max; }
    }

    // ------------------------------------------------------------------
    // Zustand
    // ------------------------------------------------------------------
    private static final Map<String, Element> ELEMENTS = new LinkedHashMap<>();
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> QUEUE = new ArrayList<>();
    private static final Set<UUID> SHIELDS = new HashSet<>();
    private static final Set<UUID> ALLIES = new HashSet<>();
    private static final Map<UUID, Anchor> ANCHORS = new HashMap<>();

    // ------------------------------------------------------------------
    // Initialisierung (EventBus 7: jedes Event hat sein eigenes BUS-Feld)
    // ------------------------------------------------------------------
    public ElementalPowersMod(FMLJavaModLoadingContext context) {
        registerAbilities();
        RegisterCommandsEvent.BUS.addListener(ElementalPowersMod::onRegisterCommands);
        TickEvent.ServerTickEvent.Post.BUS.addListener(ElementalPowersMod::onServerTick);
        ServerStoppedEvent.BUS.addListener(ElementalPowersMod::onServerStopped);

        // Menü, Tasten und HUD gibt es nur auf dem Client.
        if (isClient()) {
            ElementalPowersClient.init(context);
        }
    }

    /** Erkennt den Client, ohne eine Forge-spezifische Dist-API zu brauchen. */
    private static boolean isClient() {
        try {
            Class.forName("net.minecraft.client.Minecraft", false, ElementalPowersMod.class.getClassLoader());
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    /** Für den Client: alle Kräfte mit ihren Fähigkeiten (in Handbuch-Reihenfolge). */
    static Map<String, Element> elements() {
        return ELEMENTS;
    }

    private static void onServerStopped(ServerStoppedEvent event) {
        TASKS.clear();
        QUEUE.clear();
        SHIELDS.clear();
        ALLIES.clear();
        ANCHORS.clear();
    }

    private static void onServerTick(TickEvent.ServerTickEvent.Post event) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) tickAll(server);
    }

    private static void onRegisterCommands(RegisterCommandsEvent event) {
        var dispatcher = event.getDispatcher();
        var root = Commands.literal("power");

        for (Element el : ELEMENTS.values()) {
            var elNode = Commands.literal(el.id());
            for (Ability a : el.abilities()) {
                elNode.then(Commands.literal(a.id()).executes(ctx -> run(ctx.getSource(), a)));
            }
            elNode.executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(describe(el)), false);
                return Command.SINGLE_SUCCESS;
            });
            root.then(elNode);
        }

        root.then(Commands.literal("list").executes(ctx -> {
            StringBuilder sb = new StringBuilder("§b[Elemental Powers] §f7 Kräfte • 42 Fähigkeiten");
            for (Element el : ELEMENTS.values()) sb.append("\n").append(describe(el));
            ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
            return Command.SINGLE_SUCCESS;
        }));

        root.then(Commands.literal("clear").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayer();
            if (p == null) return 0;
            clearToggles(p);
            ctx.getSource().sendSuccess(() -> Component.literal("§b[Elemental Powers] §fDauer-Effekte abgeschaltet."), false);
            return Command.SINGLE_SUCCESS;
        }));

        dispatcher.register(root);
    }

    private static String describe(Element el) {
        StringBuilder sb = new StringBuilder("§e" + el.name() + "§7 (" + el.id() + ")");
        int i = 1;
        for (Ability a : el.abilities()) {
            sb.append("\n §7").append(i++).append(". §f").append(a.id()).append(" §7- ").append(a.desc());
        }
        return sb.toString();
    }

    private static int run(CommandSourceStack src, Ability a) {
        ServerPlayer player = src.getPlayer();
        if (player == null) {
            src.sendFailure(Component.literal("Dieser Befehl kann nur ein Spieler benutzen."));
            return 0;
        }
        Caster c = new Caster(player, (ServerLevel) player.level());
        try {
            a.action().accept(c);
        } catch (RuntimeException ex) {
            src.sendFailure(Component.literal("Fähigkeit fehlgeschlagen: " + ex));
            return 0;
        }
        src.sendSuccess(() -> Component.literal("§b[Elemental Powers] §f" + a.name() + " §7eingesetzt!"), false);
        return Command.SINGLE_SUCCESS;
    }

    // ------------------------------------------------------------------
    // Registrierung der 42 Fähigkeiten
    // ------------------------------------------------------------------
    private static void el(String id, String name, Ability... abs) {
        ELEMENTS.put(id, new Element(id, name, List.of(abs)));
    }

    private static Ability ab(String id, String name, String desc, Consumer<Caster> action) {
        return new Ability(id, name, desc, action);
    }

    private static void registerAbilities() {
        el("feuer", "Feuer",
            ab("feuerball", "Feuerball", "Schieße einen explosiven Feuerball.", ElementalPowersMod::feuerball),
            ab("flammenwerfer", "Flammenwerfer", "Erzeuge einen dauerhaften Feuerstrahl.", ElementalPowersMod::flammenwerfer),
            ab("feuerregen", "Feuerregen", "Lasse Feuerbälle vom Himmel fallen.", ElementalPowersMod::feuerregen),
            ab("feuerexplosion", "Feuerexplosion", "Erzeuge eine große Flammenwelle um dich.", ElementalPowersMod::feuerexplosion),
            ab("feuerdrache", "Feuerdrache", "Beschwöre einen Drachen aus Feuer.", ElementalPowersMod::feuerdrache),
            ab("supernova", "Supernova", "Erzeuge eine riesige Feuerexplosion.", c -> supernova(c, true)));

        el("blitz", "Blitz",
            ab("blitzstrahl", "Blitzstrahl", "Schieße einen elektrischen Strahl.", ElementalPowersMod::blitzstrahl),
            ab("kettenblitz", "Kettenblitz", "Triff mehrere Gegner nacheinander.", ElementalPowersMod::kettenblitz),
            ab("blitzschlag", "Blitzschlag", "Rufe einen Blitz auf einen Gegner.", ElementalPowersMod::blitzschlag),
            ab("teleport_blitz", "Teleport-Blitz", "Teleportiere dich blitzschnell nach vorne.", ElementalPowersMod::teleportBlitz),
            ab("blitzschild", "Blitzschild", "Umgib dich mit elektrischer Energie (An/Aus).", ElementalPowersMod::blitzschild),
            ab("donnersturm", "Donnersturm", "Erzeuge einen riesigen Gewittersturm.", ElementalPowersMod::donnersturm));

        el("eis", "Eis",
            ab("eisstrahl", "Eisstrahl", "Schieße einen Strahl, der Gegner einfriert.", ElementalPowersMod::eisstrahl),
            ab("eisspeer", "Eisspeer", "Wirf einen riesigen Eisspeer.", ElementalPowersMod::eisspeer),
            ab("eiswand", "Eiswand", "Erschaffe eine große Eiswand.", ElementalPowersMod::eiswand),
            ab("eissturm", "Eissturm", "Erzeuge einen Sturm aus Eiskristallen.", ElementalPowersMod::eissturm),
            ab("frostexplosion", "Frostexplosion", "Friere alles in deiner Umgebung ein.", ElementalPowersMod::frostexplosion),
            ab("eisdrache", "Eisdrache", "Beschwöre einen Drachen aus Eis.", ElementalPowersMod::eisdrache));

        el("schatten", "Schatten",
            ab("schattenstrahl", "Schattenstrahl", "Schieße dunkle Energie.", ElementalPowersMod::schattenstrahl),
            ab("schattenklon", "Schattenklon", "Erzeuge einen Doppelgänger.", ElementalPowersMod::schattenklon),
            ab("schattenportal", "Schattenportal", "Teleportiere dich durch ein Portal.", ElementalPowersMod::schattenportal),
            ab("dunkle_kugel", "Dunkle Kugel", "Erzeuge eine schwebende Energie-Kugel.", ElementalPowersMod::dunkleKugel),
            ab("schattenarme", "Schattenarme", "Beschwöre riesige dunkle Arme.", ElementalPowersMod::schattenarme),
            ab("nachtverschlinger", "Nachtverschlinger", "Erzeuge eine riesige Schattenzone.", ElementalPowersMod::nachtverschlinger));

        el("wind", "Wind",
            ab("windstoss", "Windstoß", "Schleudere Gegner weg.", ElementalPowersMod::windstoss),
            ab("tornado", "Tornado", "Erzeuge einen riesigen Wirbelsturm.", ElementalPowersMod::tornado),
            ab("luftklingen", "Luftklingen", "Schieße scharfe Windwellen.", ElementalPowersMod::luftklingen),
            ab("flug", "Flug", "Fliege frei durch die Luft (An/Aus).", ElementalPowersMod::flug),
            ab("windgefaengnis", "Windgefängnis", "Fange Gegner in einem Windkäfig.", ElementalPowersMod::windgefaengnis),
            ab("hurrikan", "Hurrikan", "Erzeuge einen gewaltigen Sturm.", ElementalPowersMod::hurrikan));

        el("kosmos", "Kosmos",
            ab("sternenstrahl", "Sternenstrahl", "Schieße kosmische Energie.", ElementalPowersMod::sternenstrahl),
            ab("meteor", "Meteor", "Lasse einen Meteoriten einschlagen.", ElementalPowersMod::meteor),
            ab("schwarzes_loch", "Schwarzes Loch", "Erzeuge einen Sog, der Gegner anzieht.", ElementalPowersMod::schwarzesLoch),
            ab("raumportal", "Raumportal", "Erschaffe ein Portal zu einem anderen Ort.", ElementalPowersMod::raumportal),
            ab("gravitationskontrolle", "Gravitationskontrolle", "Lasse Gegner schweben.", ElementalPowersMod::gravitationskontrolle),
            ab("supernova", "Supernova", "Erzeuge eine kosmische Explosion.", c -> supernova(c, false)));

        el("natur", "Natur",
            ab("rankenpeitsche", "Rankenpeitsche", "Greife mit riesigen Ranken an.", ElementalPowersMod::rankenpeitsche),
            ab("wurzelgefaengnis", "Wurzelgefängnis", "Halte Gegner mit Wurzeln fest.", ElementalPowersMod::wurzelgefaengnis),
            ab("dornenregen", "Dornenregen", "Lasse Dornen vom Himmel fallen.", ElementalPowersMod::dornenregen),
            ab("pflanzenmonster", "Pflanzenmonster", "Beschwöre einen riesigen Pflanzenwächter.", ElementalPowersMod::pflanzenmonster),
            ab("naturheilung", "Naturheilung", "Heile dich und deine Verbündeten.", ElementalPowersMod::naturheilung),
            ab("urwaldexplosion", "Urwaldexplosion", "Lasse riesige Pflanzen aus dem Boden wachsen.", ElementalPowersMod::urwaldexplosion));
    }

    // ==================================================================
    //  FEUER
    // ==================================================================
    private static void feuerball(Caster c) {
        sound(c, c.eye(), SoundEvents.BLAZE_SHOOT, 1.5F, 0.8F);
        projectile(c, 1.6, 80, ParticleTypes.FLAME, (pos, target) -> {
            explode(c, pos, 3.0F, true);
            particle(c, ParticleTypes.LAVA, pos, 20, 0.6, 0.1);
            for (LivingEntity e : targets(c, pos, 4)) {
                e.igniteForSeconds(8);
                damage(c, e, 6);
            }
        });
    }

    private static void flammenwerfer(Caster c) {
        sound(c, c.eye(), SoundEvents.FIRECHARGE_USE, 1.0F, 0.6F);
        schedule(100, age -> {
            if (!c.player().isAlive()) return true;
            cone(c, 9, ParticleTypes.FLAME, 25);
            cone(c, 9, ParticleTypes.SMOKE, 6);
            for (LivingEntity e : inCone(c, 9, 0.80)) {
                e.igniteForSeconds(6);
                if (age % 5 == 0) damage(c, e, 3);
            }
            return false;
        });
    }

    private static void feuerregen(Caster c) {
        Vec3 center = trace(c, 30).pos();
        rain(c, center, 10, 200, ParticleTypes.FLAME, p -> {
            explode(c, p, 1.4F, true);
            for (LivingEntity e : targets(c, p, 2.5)) {
                e.igniteForSeconds(5);
                damage(c, e, 4);
            }
        });
    }

    private static void feuerexplosion(Caster c) {
        Vec3 center = c.player().position();
        sound(c, center, SoundEvents.BLAZE_SHOOT, 2.0F, 0.5F);
        particle(c, ParticleTypes.EXPLOSION_EMITTER, center.add(0, 1, 0), 1, 0, 0);
        shockwave(c, center, 10, 12, ParticleTypes.FLAME, e -> {
            e.igniteForSeconds(8);
            damage(c, e, 10);
            push(e, e.position().subtract(center).normalize().scale(1.6).add(0, 0.6, 0));
        });
    }

    private static void feuerdrache(Caster c) {
        dragon(c, ParticleTypes.FLAME, ParticleTypes.LAVA, e -> {
            e.igniteForSeconds(8);
            damage(c, e, 8);
        });
    }

    // ==================================================================
    //  BLITZ
    // ==================================================================
    private static void blitzstrahl(Caster c) {
        Hit h = beam(c, 45, ParticleTypes.ELECTRIC_SPARK);
        sound(c, c.eye(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.6F, 2.0F);
        if (h.entity() != null) {
            damage(c, h.entity(), 10);
            particle(c, ParticleTypes.ELECTRIC_SPARK, h.pos(), 30, 0.5, 0.3);
        }
    }

    private static void kettenblitz(Caster c) {
        Hit h = trace(c, 35);
        if (h.entity() == null) { c.msg("Kein Ziel getroffen."); return; }
        Set<UUID> done = new HashSet<>();
        LivingEntity cur = h.entity();
        Vec3 from = c.eye().add(0, -0.3, 0);
        for (int i = 0; i < 6 && cur != null; i++) {
            Vec3 to = cur.getBoundingBox().getCenter();
            line(c, from, to, ParticleTypes.ELECTRIC_SPARK);
            damage(c, cur, 8);
            done.add(cur.getUUID());
            from = to;
            final Vec3 origin = to;
            cur = targets(c, to, 9).stream()
                .filter(e -> !done.contains(e.getUUID()))
                .min(Comparator.comparingDouble(e -> e.distanceToSqr(origin)))
                .orElse(null);
        }
        sound(c, h.pos(), SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 1.5F);
    }

    private static void blitzschlag(Caster c) {
        Hit h = trace(c, 70);
        lightning(c, h.pos());
    }

    private static void teleportBlitz(Caster c) {
        Hit h = trace(c, 25);
        Vec3 from = c.player().position();
        line(c, c.eye(), h.pos(), ParticleTypes.ELECTRIC_SPARK);
        teleportEye(c, h.pos());
        line(c, from.add(0, 1, 0), h.pos(), ParticleTypes.ELECTRIC_SPARK);
        sound(c, h.pos(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8F, 2.0F);
    }

    private static void blitzschild(Caster c) {
        ServerPlayer p = c.player();
        if (SHIELDS.remove(p.getUUID())) {
            p.removeEffect(MobEffects.RESISTANCE);
            p.removeEffect(MobEffects.ABSORPTION);
            c.msg("Blitzschild aus.");
        } else {
            SHIELDS.add(p.getUUID());
            p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, -1, 1, true, false));
            p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, -1, 2, true, false));
            c.msg("Blitzschild an (unendlich).");
        }
    }

    private static void donnersturm(Caster c) {
        c.world().setWeatherParameters(0, 6000, true, true);
        var rnd = c.world().getRandom();
        schedule(240, age -> {
            if (age % 8 == 0) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double dist = 5 + rnd.nextDouble() * 15;
                Vec3 base = c.player().position();
                int x = (int) Math.floor(base.x + Math.cos(ang) * dist);
                int z = (int) Math.floor(base.z + Math.sin(ang) * dist);
                int y = c.world().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
                lightning(c, new Vec3(x + 0.5, y, z + 0.5));
            }
            return false;
        });
    }

    // ==================================================================
    //  EIS
    // ==================================================================
    private static void eisstrahl(Caster c) {
        Hit h = beam(c, 40, ParticleTypes.SNOWFLAKE);
        sound(c, c.eye(), SoundEvents.GLASS_BREAK, 0.8F, 1.6F);
        if (h.entity() != null) {
            damage(c, h.entity(), 4);
            freeze(c, h.entity());
        }
    }

    private static void eisspeer(Caster c) {
        sound(c, c.eye(), SoundEvents.SNOWBALL_THROW, 1.5F, 0.6F);
        projectile(c, 2.0, 60, ParticleTypes.SNOWFLAKE, (pos, target) -> {
            particle(c, ParticleTypes.ITEM_SNOWBALL, pos, 40, 0.6, 0.1);
            sound(c, pos, SoundEvents.GLASS_BREAK, 1.5F, 0.7F);
            if (target != null) damage(c, target, 14);
            for (LivingEntity e : targets(c, pos, 3)) freeze(c, e);
        });
    }

    private static void eiswand(Caster c) {
        Direction f = c.player().getDirection();
        Direction side = f.getClockWise();
        BlockPos base = c.player().blockPosition().relative(f, 4);
        for (int w = -4; w <= 4; w++) {
            for (int h = 0; h < 4; h++) {
                BlockPos bp = base.relative(side, w).above(h);
                if (c.world().getBlockState(bp).isAir()) {
                    c.world().setBlockAndUpdate(bp, Blocks.PACKED_ICE.defaultBlockState());
                    particle(c, ParticleTypes.SNOWFLAKE, Vec3.atCenterOf(bp), 4, 0.4, 0.02);
                }
            }
        }
        sound(c, Vec3.atCenterOf(base), SoundEvents.GLASS_BREAK, 1.2F, 0.6F);
    }

    private static void eissturm(Caster c) {
        Vec3 center = trace(c, 40).pos();
        var rnd = c.world().getRandom();
        schedule(200, age -> {
            for (int i = 0; i < 40; i++) {
                Vec3 p = center.add((rnd.nextDouble() * 2 - 1) * 8, rnd.nextDouble() * 9, (rnd.nextDouble() * 2 - 1) * 8);
                particle(c, ParticleTypes.SNOWFLAKE, p, 1, 0.1, 0.05);
            }
            particle(c, ParticleTypes.CLOUD, center.add(0, 4, 0), 6, 4, 0.02);
            if (age % 10 == 0) {
                for (LivingEntity e : targets(c, center, 8)) {
                    damage(c, e, 2);
                    freeze(c, e);
                }
            }
            return false;
        });
    }

    private static void frostexplosion(Caster c) {
        Vec3 center = c.player().position();
        sound(c, center, SoundEvents.GLASS_BREAK, 2.0F, 0.5F);
        shockwave(c, center, 10, 10, ParticleTypes.SNOWFLAKE, e -> {
            damage(c, e, 8);
            freeze(c, e);
            push(e, e.position().subtract(center).normalize().scale(1.2).add(0, 0.4, 0));
        });
        BlockPos cp = c.player().blockPosition();
        int r = 8;
        for (BlockPos bp : BlockPos.betweenClosed(cp.offset(-r, -r, -r), cp.offset(r, r, r))) {
            if (bp.distSqr(cp) > r * r) continue;
            BlockState st = c.world().getBlockState(bp);
            if (st.is(Blocks.WATER)) {
                c.world().setBlockAndUpdate(bp.immutable(), Blocks.ICE.defaultBlockState());
            } else if (st.isAir()
                    && c.world().getBlockState(bp.below()).isFaceSturdy(c.world(), bp.below(), Direction.UP)
                    && Blocks.SNOW.defaultBlockState().canSurvive(c.world(), bp)) {
                c.world().setBlockAndUpdate(bp.immutable(), Blocks.SNOW.defaultBlockState());
            }
        }
    }

    private static void eisdrache(Caster c) {
        dragon(c, ParticleTypes.SNOWFLAKE, ParticleTypes.CLOUD, e -> {
            damage(c, e, 8);
            freeze(c, e);
        });
    }

    // ==================================================================
    //  SCHATTEN
    // ==================================================================
    private static void schattenstrahl(Caster c) {
        Hit h = beam(c, 40, ParticleTypes.SQUID_INK);
        line(c, c.eye().add(c.look()), h.pos(), ParticleTypes.SOUL);
        sound(c, c.eye(), SoundEvents.WITHER_SHOOT, 0.7F, 1.4F);
        if (h.entity() != null) {
            damage(c, h.entity(), 9);
            h.entity().addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1));
        }
    }

    private static void schattenklon(Caster c) {
        ServerPlayer p = c.player();
        var stand = EntityType.ARMOR_STAND.create(c.world(), EntitySpawnReason.TRIGGERED);
        if (stand == null) return;
        stand.setPos(p.getX(), p.getY(), p.getZ());
        stand.setYRot(p.getYRot());
        stand.setShowArms(true);
        stand.setNoBasePlate(true);
        stand.setCustomName(Component.literal("Schattenklon"));
        stand.setCustomNameVisible(true);
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}) {
            stand.setItemSlot(s, p.getItemBySlot(s).copy());
        }
        c.world().addFreshEntity(stand);
        particle(c, ParticleTypes.SQUID_INK, p.position().add(0, 1, 0), 40, 0.5, 0.1);
        sound(c, p.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.6F);
        schedule(SUMMON_TICKS, age -> {
            if (stand.isRemoved()) return true;
            if (age % 4 == 0) particle(c, ParticleTypes.SMOKE, stand.position().add(0, 1, 0), 3, 0.3, 0.01);
            if (age == SUMMON_TICKS - 1) {
                particle(c, ParticleTypes.SQUID_INK, stand.position().add(0, 1, 0), 40, 0.5, 0.1);
                stand.discard();
                return true;
            }
            return false;
        });
    }

    private static void schattenportal(Caster c) {
        Hit h = trace(c, 35);
        Vec3 from = c.player().position().add(0, 1, 0);
        particle(c, ParticleTypes.REVERSE_PORTAL, from, 60, 0.5, 0.3);
        teleportEye(c, h.pos());
        particle(c, ParticleTypes.REVERSE_PORTAL, c.player().position().add(0, 1, 0), 60, 0.5, 0.3);
    }

    private static void dunkleKugel(Caster c) {
        Vec3 dir = c.look();
        Vec3[] pos = {c.eye().add(dir.scale(3))};
        sound(c, pos[0], SoundEvents.WITHER_SHOOT, 1.0F, 0.5F);
        schedule(160, age -> {
            Vec3 next = pos[0].add(dir.scale(0.25));
            BlockPos bp = BlockPos.containing(next);
            if (c.world().getBlockState(bp).getCollisionShape(c.world(), bp).isEmpty()) pos[0] = next;
            particle(c, ParticleTypes.SQUID_INK, pos[0], 25, 0.5, 0.05);
            particle(c, ParticleTypes.PORTAL, pos[0], 15, 0.8, 0.5);
            for (LivingEntity e : targets(c, pos[0], 6)) {
                Vec3 pull = pos[0].subtract(e.position()).normalize().scale(0.25);
                push(e, e.getDeltaMovement().scale(0.6).add(pull));
                if (age % 5 == 0) damage(c, e, 2);
            }
            return false;
        });
    }

    private static void schattenarme(Caster c) {
        List<LivingEntity> victims = targets(c, c.player().position(), 20).stream()
            .sorted(Comparator.comparingDouble(e -> e.distanceToSqr(c.player())))
            .limit(6).toList();
        if (victims.isEmpty()) { c.msg("Keine Gegner in der Nähe."); return; }
        for (LivingEntity v : victims) {
            Vec3 at = v.position();
            sound(c, at, SoundEvents.WITHER_SHOOT, 0.8F, 0.4F);
            schedule(100, age -> {
                if (!v.isAlive()) return true;
                pin(v, at);
                for (int k = 0; k < 6; k++) {
                    double ang = k * Math.PI / 3 + age * 0.1;
                    for (double y = 0; y < 3.2; y += 0.4) {
                        double rad = 1.1 - y * 0.12;
                        particle(c, ParticleTypes.SQUID_INK, at.add(Math.cos(ang) * rad, y, Math.sin(ang) * rad), 1, 0.05, 0);
                    }
                }
                if (age % 10 == 0) damage(c, v, 2);
                return false;
            });
        }
    }

    private static void nachtverschlinger(Caster c) {
        Vec3 center = c.player().position();
        var rnd = c.world().getRandom();
        sound(c, center, SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.5F);
        schedule(300, age -> {
            for (int i = 0; i < 40; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double d = Math.sqrt(rnd.nextDouble()) * 12;
                particle(c, ParticleTypes.SQUID_INK, center.add(Math.cos(ang) * d, 0.2 + rnd.nextDouble() * 2.5, Math.sin(ang) * d), 1, 0.1, 0.01);
            }
            if (age % 10 == 0) {
                for (LivingEntity e : targets(c, center, 12)) {
                    e.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0));
                    e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                    e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 2));
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
                    damage(c, e, 2);
                }
            }
            return false;
        });
    }

    // ==================================================================
    //  WIND
    // ==================================================================
    private static void windstoss(Caster c) {
        sound(c, c.eye(), SoundEvents.PHANTOM_FLAP, 2.0F, 0.5F);
        cone(c, 12, ParticleTypes.CLOUD, 120);
        Vec3 look = c.look();
        for (LivingEntity e : inCone(c, 12, 0.6)) {
            damage(c, e, 2);
            push(e, look.scale(2.8).add(0, 0.6, 0));
        }
    }

    private static void tornado(Caster c) {
        Vec3 center = trace(c, 25).pos();
        sound(c, center, SoundEvents.ENDER_DRAGON_FLAP, 2.0F, 0.5F);
        vortex(c, () -> center, 6, 12, 200, 0.45, 3);
    }

    private static void luftklingen(Caster c) {
        sound(c, c.eye(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.5F, 0.8F);
        for (double deg : new double[]{-18, 0, 18}) {
            Vec3 dir = c.look().yRot((float) Math.toRadians(deg));
            Set<UUID> hit = new HashSet<>();
            for (double d = 1.5; d <= 22; d += 0.5) {
                Vec3 p = c.eye().add(dir.scale(d)).add(0, -0.3, 0);
                BlockPos bp = BlockPos.containing(p);
                if (!c.world().getBlockState(bp).getCollisionShape(c.world(), bp).isEmpty()) break;
                particle(c, ParticleTypes.CLOUD, p, 2, 0.1, 0.01);
                if (((int) (d * 2)) % 4 == 0) particle(c, ParticleTypes.SWEEP_ATTACK, p, 1, 0, 0);
                for (LivingEntity e : targets(c, p, 1.4)) {
                    if (hit.add(e.getUUID())) damage(c, e, 7);
                }
            }
        }
    }

    private static void flug(Caster c) {
        ServerPlayer p = c.player();
        if (p.isCreative() || p.isSpectator()) { c.msg("Im Kreativ-/Zuschauermodus kannst du ohnehin fliegen."); return; }
        var abilities = p.getAbilities();
        if (abilities.mayfly) {
            abilities.mayfly = false;
            abilities.flying = false;
            c.msg("Flug aus.");
        } else {
            abilities.mayfly = true;
            abilities.flying = true;
            p.setDeltaMovement(p.getDeltaMovement().add(0, 0.5, 0));
            p.hurtMarked = true;
            c.msg("Flug an (unendlich). Doppelt Springen schaltet den Flugmodus um.");
        }
        p.onUpdateAbilities();
        particle(c, ParticleTypes.CLOUD, p.position(), 30, 0.5, 0.05);
    }

    private static void windgefaengnis(Caster c) {
        Hit h = trace(c, 30);
        if (h.entity() == null) { c.msg("Kein Ziel getroffen."); return; }
        sound(c, h.pos(), SoundEvents.PHANTOM_FLAP, 2.0F, 0.6F);
        trap(c, h.entity(), 160, ParticleTypes.CLOUD, 1);
    }

    private static void hurrikan(Caster c) {
        c.world().setWeatherParameters(0, 6000, true, true);
        sound(c, c.player().position(), SoundEvents.ENDER_DRAGON_FLAP, 2.5F, 0.4F);
        vortex(c, () -> c.player().position(), 18, 16, 300, 0.7, 3);
    }

    // ==================================================================
    //  KOSMOS
    // ==================================================================
    private static void sternenstrahl(Caster c) {
        Hit h = beam(c, 50, ParticleTypes.END_ROD);
        line(c, c.eye().add(c.look()), h.pos(), ParticleTypes.ENCHANT);
        sound(c, c.eye(), SoundEvents.ILLUSIONER_CAST_SPELL, 1.0F, 1.5F);
        if (h.entity() != null) {
            damage(c, h.entity(), 12);
            h.entity().addEffect(new MobEffectInstance(MobEffects.GLOWING, DEBUFF_TICKS, 0));
        }
    }

    private static void meteor(Caster c) {
        Vec3 target = trace(c, 60).pos();
        var rnd = c.world().getRandom();
        Vec3 start = target.add((rnd.nextDouble() - 0.5) * 12, 45, (rnd.nextDouble() - 0.5) * 12);
        sound(c, target, SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 0.5F);
        final int fall = 40;
        schedule(fall + 1, age -> {
            double t = Math.min(1.0, (age + 1) / (double) fall);
            Vec3 pos = start.lerp(target, t);
            particle(c, ParticleTypes.FLAME, pos, 40, 1.0, 0.05);
            particle(c, ParticleTypes.LAVA, pos, 8, 0.8, 0.0);
            particle(c, ParticleTypes.LARGE_SMOKE, pos, 20, 1.2, 0.02);
            if (t >= 1.0) {
                explode(c, target, 5.0F, true);
                shockwave(c, target, 9, 8, ParticleTypes.FLAME, e -> {
                    e.igniteForSeconds(6);
                    damage(c, e, 15);
                    push(e, e.position().subtract(target).normalize().scale(1.4).add(0, 0.6, 0));
                });
                return true;
            }
            return false;
        });
    }

    private static void schwarzesLoch(Caster c) {
        Vec3 center = trace(c, 40).pos().add(0, 2.5, 0);
        sound(c, center, SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 0.3F);
        var rnd = c.world().getRandom();
        schedule(160, age -> {
            particle(c, ParticleTypes.SQUID_INK, center, 40, 0.7, 0.02);
            for (int i = 0; i < 25; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2;
                double d = 2 + rnd.nextDouble() * 6;
                Vec3 p = center.add(Math.cos(ang) * d, (rnd.nextDouble() - 0.5) * 2, Math.sin(ang) * d);
                particle(c, ParticleTypes.PORTAL, p, 1, 0.1, 0.0);
            }
            for (LivingEntity e : targets(c, center, 14)) {
                Vec3 to = center.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
                double dist = Math.max(1.0, to.length());
                push(e, e.getDeltaMovement().scale(0.85).add(to.normalize().scale(Math.min(0.55, 5.0 / (dist * dist) + 0.08))));
                if (dist < 3 && age % 5 == 0) damage(c, e, 3);
            }
            if (age == 159) {
                explode(c, center, 3.0F, false);
                return true;
            }
            return false;
        });
    }

    private static void raumportal(Caster c) {
        ServerPlayer p = c.player();
        Anchor old = ANCHORS.get(p.getUUID());
        Vec3 here = p.position();
        ResourceKey<Level> dim = c.world().dimension();
        if (old == null) {
            ANCHORS.put(p.getUUID(), new Anchor(dim, here));
            particle(c, ParticleTypes.PORTAL, here.add(0, 1, 0), 80, 0.6, 0.6);
            c.msg("Portalpunkt gesetzt. Nutze Raumportal erneut, um dorthin zu springen.");
            return;
        }
        if (!old.dim().equals(dim)) { c.msg("Dein Portalpunkt liegt in einer anderen Dimension."); return; }
        ANCHORS.put(p.getUUID(), new Anchor(dim, here)); // Tauschen: zurückspringen möglich
        particle(c, ParticleTypes.PORTAL, here.add(0, 1, 0), 80, 0.6, 0.6);
        p.connection.teleport(old.pos().x, old.pos().y, old.pos().z, p.getYRot(), p.getXRot());
        p.resetFallDistance();
        particle(c, ParticleTypes.PORTAL, old.pos().add(0, 1, 0), 80, 0.6, 0.6);
        sound(c, old.pos(), SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.5F);
    }

    private static void gravitationskontrolle(Caster c) {
        List<LivingEntity> victims = targets(c, c.player().position(), 15);
        if (victims.isEmpty()) { c.msg("Keine Gegner in der Nähe."); return; }
        sound(c, c.player().position(), SoundEvents.ILLUSIONER_CAST_SPELL, 1.5F, 0.5F);
        for (LivingEntity v : victims) {
            double targetY = v.getY() + 3;
            v.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0));
            schedule(160, age -> {
                if (!v.isAlive()) return true;
                double vy = Math.max(-0.1, Math.min(0.1, (targetY - v.getY()) * 0.1));
                push(v, new Vec3(v.getDeltaMovement().x * 0.5, vy, v.getDeltaMovement().z * 0.5));
                v.resetFallDistance();
                if (age % 3 == 0) particle(c, ParticleTypes.END_ROD, v.position(), 2, 0.4, 0.02);
                return false;
            });
        }
    }

    // ==================================================================
    //  NATUR
    // ==================================================================
    private static void rankenpeitsche(Caster c) {
        Hit h = trace(c, 22);
        Vec3 start = c.eye().add(c.look()).add(0, -0.4, 0);
        line(c, start, h.pos(), ParticleTypes.COMPOSTER);
        line(c, start, h.pos(), ParticleTypes.HAPPY_VILLAGER);
        sound(c, h.pos(), SoundEvents.GRASS_BREAK, 1.5F, 0.6F);
        if (h.entity() != null) {
            LivingEntity e = h.entity();
            damage(c, e, 6);
            Vec3 pull = c.player().position().subtract(e.position()).normalize().scale(1.3).add(0, 0.3, 0);
            push(e, pull);
        }
    }

    private static void wurzelgefaengnis(Caster c) {
        Hit h = trace(c, 30);
        if (h.entity() == null) { c.msg("Kein Ziel getroffen."); return; }
        sound(c, h.pos(), SoundEvents.GRASS_BREAK, 2.0F, 0.5F);
        trap(c, h.entity(), 160, new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LOG.defaultBlockState()), 2);
    }

    private static void dornenregen(Caster c) {
        Vec3 center = trace(c, 30).pos();
        rain(c, center, 10, 200, ParticleTypes.COMPOSTER, p -> {
            particle(c, ParticleTypes.CRIT, p.add(0, 0.3, 0), 10, 0.3, 0.2);
            for (LivingEntity e : targets(c, p, 2.5)) {
                damage(c, e, 3);
                e.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 1));
            }
        });
    }

    private static void pflanzenmonster(Caster c) {
        ServerPlayer p = c.player();
        var g = EntityType.IRON_GOLEM.create(c.world(), EntitySpawnReason.TRIGGERED);
        if (g == null) return;
        Vec3 pos = p.position().add(c.look().scale(3));
        g.setPos(pos.x, pos.y, pos.z);
        g.setYRot(p.getYRot());
        g.setPersistenceRequired();
        g.setCustomName(Component.literal("Pflanzenwächter"));
        g.setCustomNameVisible(true);
        AttributeInstance scale = g.getAttribute(Attributes.SCALE);
        if (scale != null) scale.setBaseValue(2.0);
        g.addEffect(new MobEffectInstance(MobEffects.STRENGTH, -1, 3));
        g.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, -1, 2));
        g.addEffect(new MobEffectInstance(MobEffects.REGENERATION, -1, 1));
        c.world().addFreshEntity(g);
        ALLIES.add(g.getUUID());
        particle(c, ParticleTypes.HAPPY_VILLAGER, pos.add(0, 2, 0), 80, 1.2, 0.1);
        sound(c, pos, SoundEvents.GRASS_BREAK, 2.0F, 0.4F);
        schedule(SUMMON_TICKS, age -> {
            if (g.isRemoved()) { ALLIES.remove(g.getUUID()); return true; }
            if (age % 10 == 0) particle(c, ParticleTypes.HAPPY_VILLAGER, g.position().add(0, 2, 0), 3, 0.8, 0.0);
            if (age == SUMMON_TICKS - 1) {
                particle(c, ParticleTypes.HAPPY_VILLAGER, g.position().add(0, 2, 0), 60, 1.0, 0.1);
                ALLIES.remove(g.getUUID());
                g.discard();
                return true;
            }
            return false;
        });
    }

    private static void naturheilung(Caster c) {
        Vec3 center = c.player().position();
        List<LivingEntity> friends = c.world().getEntitiesOfClass(LivingEntity.class, AABB.ofSize(center, 24, 24, 24),
            e -> e.isAlive() && e.distanceToSqr(center) <= 144
                && (e instanceof Player || e instanceof TamableAnimal || ALLIES.contains(e.getUUID())));
        for (LivingEntity e : friends) {
            e.heal(20.0F);
            e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
            e.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 1));
            particle(c, ParticleTypes.HAPPY_VILLAGER, e.position().add(0, 1, 0), 30, 0.5, 0.1);
        }
        shockwave(c, center, 12, 10, ParticleTypes.HAPPY_VILLAGER, e -> {});
        sound(c, center, SoundEvents.PLAYER_LEVELUP, 1.0F, 1.2F);
    }

    private static void urwaldexplosion(Caster c) {
        Vec3 center = c.player().position();
        var rnd = c.world().getRandom();
        SaplingBlock[] saplings = {
            (SaplingBlock) Blocks.OAK_SAPLING, (SaplingBlock) Blocks.BIRCH_SAPLING,
            (SaplingBlock) Blocks.SPRUCE_SAPLING, (SaplingBlock) Blocks.ACACIA_SAPLING
        };
        sound(c, center, SoundEvents.GRASS_BREAK, 2.0F, 0.3F);
        shockwave(c, center, 12, 12, ParticleTypes.HAPPY_VILLAGER, e -> {
            damage(c, e, 6);
            e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DEBUFF_TICKS, 3));
        });
        for (int i = 0; i < 45; i++) {
            int x = (int) Math.floor(center.x + (rnd.nextDouble() * 2 - 1) * 12);
            int z = (int) Math.floor(center.z + (rnd.nextDouble() * 2 - 1) * 12);
            int y = c.world().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!c.world().getBlockState(pos).isAir()) continue;
            if (!c.world().getBlockState(pos.below()).is(BlockTags.DIRT)) continue;
            SaplingBlock sapling = saplings[rnd.nextInt(saplings.length)];
            BlockState grown = sapling.defaultBlockState().setValue(SaplingBlock.STAGE, 1);
            c.world().setBlockAndUpdate(pos, grown);
            sapling.performBonemeal(c.world(), rnd, pos, grown);
            particle(c, ParticleTypes.HAPPY_VILLAGER, Vec3.atCenterOf(pos), 12, 0.6, 0.1);
        }
    }

    // ==================================================================
    //  SUPERNOVA (Feuer & Kosmos)
    // ==================================================================
    private static void supernova(Caster c, boolean fire) {
        ParticleOptions main = fire ? ParticleTypes.FLAME : ParticleTypes.END_ROD;
        ParticleOptions second = fire ? ParticleTypes.LAVA : ParticleTypes.ENCHANT;
        Vec3 center = trace(c, 60).pos();
        // Zu nah dran? Dann weiter weg zünden, damit du nicht mitsterbst.
        if (center.distanceTo(c.eye()) < 18) center = c.eye().add(c.look().scale(18));
        final Vec3 at = center;
        c.player().addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 200, 4));
        c.player().addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0));
        sound(c, at, SoundEvents.ENDER_DRAGON_GROWL, 3.0F, 0.4F);
        var rnd = c.world().getRandom();
        final int charge = 50;
        schedule(charge + 1, age -> {
            double r = 8.0 * (1.0 - age / (double) charge) + 0.5;
            for (int i = 0; i < 40; i++) {
                double th = rnd.nextDouble() * Math.PI * 2, ph = Math.acos(2 * rnd.nextDouble() - 1);
                Vec3 p = at.add(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph), r * Math.sin(ph) * Math.sin(th));
                particle(c, i % 3 == 0 ? second : main, p, 1, 0.05, 0.0);
            }
            if (age == charge) {
                particle(c, ParticleTypes.EXPLOSION_EMITTER, at, 3, 3, 0);
                explode(c, at, 12.0F, fire);
                shockwave(c, at, 25, 20, main, e -> {
                    if (fire) e.igniteForSeconds(10);
                    damage(c, e, 20);
                    push(e, e.position().subtract(at).normalize().scale(2.2).add(0, 0.8, 0));
                });
                return true;
            }
            return false;
        });
    }

    // ==================================================================
    //  HILFSFUNKTIONEN: Scheduler & Toggles
    // ==================================================================
    static void schedule(int maxTicks, Tick tick) {
        QUEUE.add(new Task(tick, maxTicks));
    }

    private static void tickAll(MinecraftServer server) {
        TASKS.addAll(QUEUE);
        QUEUE.clear();
        TASKS.removeIf(t -> {
            try {
                boolean done = t.tick.run(t.age++);
                return done || t.age >= t.max;
            } catch (RuntimeException ex) {
                return true;
            }
        });

        // Blitzschild: Partikel + Schock für Monster in der Nähe
        for (UUID id : new ArrayList<>(SHIELDS)) {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null || !p.isAlive()) continue;
            ServerLevel w = (ServerLevel) p.level();
            Caster c = new Caster(p, w);
            for (int i = 0; i < 4; i++) {
                double ang = Math.random() * Math.PI * 2;
                particle(c, ParticleTypes.ELECTRIC_SPARK,
                    p.position().add(Math.cos(ang) * 0.9, Math.random() * 2, Math.sin(ang) * 0.9), 1, 0.05, 0.02);
            }
            if (server.getTickCount() % 10 == 0) {
                for (LivingEntity e : targets(c, p.position().add(0, 1, 0), 2.5)) {
                    if (e instanceof Monster) {
                        damage(c, e, 3);
                        push(e, e.position().subtract(p.position()).normalize().scale(0.8).add(0, 0.3, 0));
                    }
                }
            }
        }
    }

    private static void clearToggles(ServerPlayer p) {
        if (SHIELDS.remove(p.getUUID())) {
            p.removeEffect(MobEffects.RESISTANCE);
            p.removeEffect(MobEffects.ABSORPTION);
        }
        if (!p.isCreative() && !p.isSpectator()) {
            p.getAbilities().mayfly = false;
            p.getAbilities().flying = false;
            p.onUpdateAbilities();
        }
    }

    // ==================================================================
    //  HILFSFUNKTIONEN: Ziele, Schaden, Partikel
    // ==================================================================
    static boolean isEnemy(Caster c, LivingEntity e) {
        return e != c.player() && e.isAlive() && !e.isSpectator()
            && e.getType() != EntityType.ARMOR_STAND
            && !ALLIES.contains(e.getUUID())
            && !(e instanceof TamableAnimal t && t.isOwnedBy(c.player()));
    }

    static List<LivingEntity> targets(Caster c, Vec3 center, double r) {
        return c.world().getEntitiesOfClass(LivingEntity.class, AABB.ofSize(center, r * 2, r * 2, r * 2),
            e -> isEnemy(c, e) && e.distanceToSqr(center) <= r * r);
    }

    static List<LivingEntity> inCone(Caster c, double range, double minDot) {
        Vec3 eye = c.eye(), look = c.look();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : targets(c, eye, range)) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            if (to.lengthSqr() < 1e-6 || to.normalize().dot(look) >= minDot) out.add(e);
        }
        return out;
    }

    static Hit trace(Caster c, double range) {
        return trace(c, c.look(), range);
    }

    static Hit trace(Caster c, Vec3 dir, double range) {
        Vec3 eye = c.eye();
        Vec3 last = eye;
        for (double d = 0.5; d <= range; d += 0.5) {
            Vec3 p = eye.add(dir.scale(d));
            for (LivingEntity target : c.world().getEntitiesOfClass(LivingEntity.class, AABB.ofSize(p, 4, 4, 4), x -> isEnemy(c, x))) {
                if (target.getBoundingBox().inflate(0.3).contains(p)) {
                    return new Hit(target.getBoundingBox().getCenter(), target);
                }
            }
            BlockPos bp = BlockPos.containing(p);
            if (!c.world().getBlockState(bp).getCollisionShape(c.world(), bp).isEmpty()) return new Hit(last, null);
            last = p;
        }
        return new Hit(last, null);
    }

    static void damage(Caster c, LivingEntity e, float amount) {
        e.hurtServer(c.world(), c.world().damageSources().playerAttack(c.player()), amount);
    }

    static void push(Entity e, Vec3 v) {
        e.setDeltaMovement(v);
        e.hurtMarked = true;
    }

    static void pin(Entity e, Vec3 at) {
        if (e instanceof ServerPlayer sp) {
            sp.connection.teleport(at.x, at.y, at.z, sp.getYRot(), sp.getXRot());
        } else {
            e.setPos(at.x, at.y, at.z);
        }
        e.setDeltaMovement(Vec3.ZERO);
        e.hurtMarked = true;
    }

    static void freeze(Caster c, LivingEntity e) {
        e.setTicksFrozen(e.getTicksRequiredToFreeze() + 40);
        e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DEBUFF_TICKS, 6));
        e.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, DEBUFF_TICKS, 2));
        particle(c, ParticleTypes.SNOWFLAKE, e.getBoundingBox().getCenter(), 30, 0.4, 0.02);
    }

    static void explode(Caster c, Vec3 pos, float power, boolean fire) {
        c.world().explode((Entity) null, pos.x, pos.y, pos.z, power, fire,
            BLOCK_DAMAGE ? Level.ExplosionInteraction.MOB : Level.ExplosionInteraction.NONE);
    }

    static void lightning(Caster c, Vec3 pos) {
        var bolt = EntityType.LIGHTNING_BOLT.create(c.world(), EntitySpawnReason.TRIGGERED);
        if (bolt == null) return;
        bolt.setPos(pos.x, pos.y, pos.z);
        bolt.setCause(c.player());
        c.world().addFreshEntity(bolt);
    }

    static void particle(Caster c, ParticleOptions p, Vec3 pos, int count, double spread, double speed) {
        c.world().sendParticles(p, pos.x, pos.y, pos.z, count, spread, spread, spread, speed);
    }

    static void sound(Caster c, Vec3 pos, SoundEvent s, float vol, float pitch) {
        c.world().playSound((Player) null, pos.x, pos.y, pos.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    static void sound(Caster c, Vec3 pos, Holder<SoundEvent> s, float vol, float pitch) {
        sound(c, pos, s.value(), vol, pitch);
    }

    static void line(Caster c, Vec3 a, Vec3 b, ParticleOptions p) {
        double len = a.distanceTo(b);
        if (len < 1e-3) return;
        Vec3 dir = b.subtract(a).normalize();
        for (double d = 0; d <= len; d += 0.4) {
            particle(c, p, a.add(dir.scale(d)), 1, 0.03, 0);
        }
    }

    static Hit beam(Caster c, double range, ParticleOptions p) {
        Hit h = trace(c, range);
        Vec3 start = c.eye().add(c.look()).add(0, -0.25, 0);
        line(c, start, h.pos(), p);
        return h;
    }

    static void teleportEye(Caster c, Vec3 eyePos) {
        ServerPlayer p = c.player();
        double eyeH = p.getEyeY() - p.getY();
        Vec3 feet = eyePos.subtract(0, eyeH, 0);
        AABB box = p.getBoundingBox().move(feet.subtract(p.position()));
        for (int i = 0; i < 4 && !c.world().noCollision(p, box); i++) {
            box = box.move(0, 1, 0);
            feet = feet.add(0, 1, 0);
        }
        particle(c, ParticleTypes.PORTAL, p.position().add(0, 1, 0), 40, 0.4, 0.5);
        p.connection.teleport(feet.x, feet.y, feet.z, p.getYRot(), p.getXRot());
        p.resetFallDistance();
        particle(c, ParticleTypes.PORTAL, feet.add(0, 1, 0), 40, 0.4, 0.5);
        sound(c, feet, SoundEvents.ENDERMAN_TELEPORT, 1.0F, 1.0F);
    }

    // ==================================================================
    //  HILFSFUNKTIONEN: wiederverwendbare Muster
    // ==================================================================

    /** Fliegendes Geschoss mit Trefferprüfung. */
    static void projectile(Caster c, double speed, int maxTicks, ParticleOptions trail, BiConsumer<Vec3, LivingEntity> impact) {
        Vec3 dir = c.look();
        Vec3[] pos = {c.eye().add(dir.scale(1.5))};
        schedule(maxTicks, age -> {
            for (int i = 0; i < 4; i++) {
                Vec3 next = pos[0].add(dir.scale(speed / 4));
                BlockPos bp = BlockPos.containing(next);
                LivingEntity hit = null;
                for (LivingEntity e : c.world().getEntitiesOfClass(LivingEntity.class, AABB.ofSize(next, 4, 4, 4), x -> isEnemy(c, x))) {
                    if (e.getBoundingBox().inflate(0.3).contains(next)) { hit = e; break; }
                }
                boolean blocked = !c.world().getBlockState(bp).getCollisionShape(c.world(), bp).isEmpty();
                if (hit != null || blocked) {
                    impact.accept(hit != null ? next : pos[0], hit);
                    return true;
                }
                pos[0] = next;
                particle(c, trail, pos[0], 3, 0.1, 0.01);
            }
            return false;
        });
    }

    /** Partikelkegel vor dem Spieler (Flammenwerfer, Windstoß). */
    static void cone(Caster c, double range, ParticleOptions p, int count) {
        var rnd = c.world().getRandom();
        Vec3 eye = c.eye(), look = c.look();
        for (int i = 0; i < count; i++) {
            double d = 1 + rnd.nextDouble() * (range - 1);
            double spread = d * 0.22;
            Vec3 pos = eye.add(look.scale(d)).add(
                (rnd.nextDouble() * 2 - 1) * spread,
                (rnd.nextDouble() * 2 - 1) * spread - 0.3,
                (rnd.nextDouble() * 2 - 1) * spread);
            particle(c, p, pos, 1, 0.02, 0.01);
        }
    }

    /** Sich ausbreitende Welle, die jeden Gegner einmal trifft. */
    static void shockwave(Caster c, Vec3 center, double maxR, int ticks, ParticleOptions p, Consumer<LivingEntity> onHit) {
        Set<UUID> hit = new HashSet<>();
        var rnd = c.world().getRandom();
        schedule(ticks, age -> {
            double r = maxR * (age + 1) / ticks;
            int n = (int) (r * 14);
            for (int i = 0; i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                particle(c, p, center.add(Math.cos(a) * r, 0.3 + rnd.nextDouble() * 0.6, Math.sin(a) * r), 1, 0.05, 0.02);
            }
            for (LivingEntity e : targets(c, center, r)) {
                if (hit.add(e.getUUID())) onHit.accept(e);
            }
            return false;
        });
    }

    /** Regen aus dem Himmel (Feuerregen, Dornenregen). */
    static void rain(Caster c, Vec3 center, double radius, int ticks, ParticleOptions drop, Consumer<Vec3> impact) {
        var rnd = c.world().getRandom();
        schedule(ticks, age -> {
            if (age % 2 == 0) {
                for (int i = 0; i < 3; i++) {
                    double x = center.x + (rnd.nextDouble() * 2 - 1) * radius;
                    double z = center.z + (rnd.nextDouble() * 2 - 1) * radius;
                    int top = c.world().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
                    Vec3 ground = new Vec3(x, top, z);
                    line(c, ground.add(0, 18, 0), ground, drop);
                    impact.accept(ground);
                }
            }
            return false;
        });
    }

    /** Drache aus Partikeln, der sich schlangenförmig nach vorne bewegt und alles berührt. */
    static void dragon(Caster c, ParticleOptions body, ParticleOptions aura, Consumer<LivingEntity> touch) {
        Vec3 origin = c.eye().add(0, -0.5, 0);
        Vec3 dir = c.look();
        Vec3 side0 = dir.cross(new Vec3(0, 1, 0));
        if (side0.lengthSqr() < 1e-4) side0 = new Vec3(1, 0, 0);
        final Vec3 side = side0.normalize();
        final Vec3 up = side.cross(dir).normalize();
        sound(c, origin, SoundEvents.ENDER_DRAGON_GROWL, 3.0F, 1.0F);

        java.util.function.DoubleFunction<Vec3> pointAt = t -> origin
            .add(dir.scale(2 + t * 0.7))
            .add(side.scale(Math.sin(t * 0.35) * 2.5))
            .add(up.scale(Math.cos(t * 0.25) * 1.2));

        schedule(110, age -> {
            Vec3 head = pointAt.apply(age);
            for (int i = 0; i < 20; i++) {
                double t = age - i * 1.5;
                if (t < 0) break;
                double spread = Math.max(0.12, 0.5 - i * 0.02);
                particle(c, body, pointAt.apply(t), 6, spread, 0.01);
            }
            particle(c, aura, head, 15, 0.7, 0.05);
            particle(c, ParticleTypes.END_ROD, head, 6, 0.5, 0.02);
            if (age % 25 == 0) sound(c, head, SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 1.2F);
            if (age % 4 == 0) {
                for (LivingEntity e : targets(c, head, 3.2)) touch.accept(e);
            }
            return false;
        });
    }

    /** Wirbel um einen Punkt (Tornado, Hurrikan): hebt, dreht und verletzt Gegner. */
    static void vortex(Caster c, Supplier<Vec3> centerSupplier, double radius, double height, int ticks, double force, float dmg) {
        schedule(ticks, age -> {
            Vec3 cen = centerSupplier.get();
            for (double h = 0; h < height; h += 0.5) {
                double r = 0.6 + h * (radius / height) * 0.6;
                for (int arm = 0; arm < 2; arm++) {
                    double ang = age * 0.45 + h * 0.7 + arm * Math.PI;
                    particle(c, ParticleTypes.CLOUD, cen.add(Math.cos(ang) * r, h, Math.sin(ang) * r), 1, 0.1, 0.0);
                }
            }
            for (LivingEntity e : targets(c, cen, radius)) {
                Vec3 rel = e.position().subtract(cen);
                Vec3 tang = new Vec3(-rel.z, 0, rel.x).normalize().scale(force);
                Vec3 pull = new Vec3(-rel.x, 0, -rel.z).scale(0.06);
                double up = (e.getY() - cen.y) < height ? 0.38 : 0.0;
                push(e, new Vec3(tang.x + pull.x, up, tang.z + pull.z));
                e.resetFallDistance();
                if (age % 10 == 0) damage(c, e, dmg);
            }
            return false;
        });
    }

    /** Käfig um ein Ziel (Windgefängnis, Wurzelgefängnis). */
    static void trap(Caster c, LivingEntity target, int ticks, ParticleOptions p, float dmgPerSecond) {
        Vec3 at = target.position();
        schedule(ticks, age -> {
            if (!target.isAlive()) return true;
            pin(target, at);
            for (int k = 0; k < 12; k++) {
                double ang = k * Math.PI / 6 + age * 0.15;
                for (double y : new double[]{0.2, 1.0, 1.8}) {
                    particle(c, p, at.add(Math.cos(ang) * 1.2, y, Math.sin(ang) * 1.2), 1, 0.02, 0);
                }
            }
            if (age % 20 == 0 && dmgPerSecond > 0) damage(c, target, dmgPerSecond);
            return false;
        });
    }
}
