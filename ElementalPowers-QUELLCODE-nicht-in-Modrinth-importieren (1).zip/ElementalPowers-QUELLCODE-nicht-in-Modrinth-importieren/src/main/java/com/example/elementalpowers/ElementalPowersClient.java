package com.example.elementalpowers;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraftforge.client.event.AddGuiOverlayLayersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.ForgeLayeredDraw;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;

/**
 * Nur Client: Auswahlmenü beim Betreten einer Welt, Tastenbelegung und
 * Anzeige oben links, welche Taste welche Attacke auslöst.
 *
 * Die Attacken selbst laufen weiter über die Server-Befehle (/power ...),
 * der Client schickt beim Tastendruck einfach den passenden Befehl.
 */
final class ElementalPowersClient {
    private ElementalPowersClient() {}

    // ------------------------------------------------------------------
    // Tasten
    // ------------------------------------------------------------------
    private static final KeyMapping.Category CATEGORY =
        KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ElementalPowersMod.MOD_ID, "powers"));

    /** Standardtasten für Fähigkeit 1-6 (änderbar unter Optionen > Steuerung). */
    private static final int[] DEFAULT_KEYS = {
        GLFW.GLFW_KEY_R, GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_Z,
        GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V
    };

    private static final KeyMapping MENU_KEY = new KeyMapping(
        "key.elementalpowers.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, CATEGORY);

    private static final KeyMapping[] ABILITY_KEYS = new KeyMapping[6];

    static {
        for (int i = 0; i < ABILITY_KEYS.length; i++) {
            ABILITY_KEYS[i] = new KeyMapping(
                "key.elementalpowers.ability" + (i + 1), InputConstants.Type.KEYSYM, DEFAULT_KEYS[i], CATEGORY);
        }
    }

    // ------------------------------------------------------------------
    // Zustand
    // ------------------------------------------------------------------
    /** ID der gewählten Kraft (z.B. "feuer") oder null. */
    private static String selected = null;
    private static boolean menuShown = false;

    // ------------------------------------------------------------------
    // Anmeldung der Events (EventBus 7)
    // ------------------------------------------------------------------
    static void init(FMLJavaModLoadingContext context) {
        // Mod-Bus-Event: braucht die BusGroup des Mods
        RegisterKeyMappingsEvent.getBus(context.getModBusGroup()).addListener(ElementalPowersClient::onRegisterKeys);
        // Game-Bus-Events
        TickEvent.ClientTickEvent.Post.BUS.addListener(ElementalPowersClient::onClientTick);
        AddGuiOverlayLayersEvent.BUS.addListener(ElementalPowersClient::onAddLayers);
    }

    private static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(MENU_KEY);
        for (KeyMapping k : ABILITY_KEYS) event.register(k);
    }

    private static void onAddLayers(AddGuiOverlayLayersEvent event) {
        event.getLayeredDraw().addAbove(
            ForgeLayeredDraw.PRE_SLEEP_STACK,
            Identifier.fromNamespaceAndPath(ElementalPowersMod.MOD_ID, "hud"),
            ForgeLayeredDraw.HOTBAR_AND_DECOS,
            ElementalPowersClient::renderHud);
    }

    // ------------------------------------------------------------------
    // Tick: Menü automatisch öffnen + Tasten abfragen
    // ------------------------------------------------------------------
    private static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            menuShown = false; // beim nächsten Betreten wieder zeigen
            return;
        }

        // Am Anfang: Auswahlmenü
        if (!menuShown && mc.screen == null) {
            menuShown = true;
            mc.setScreen(new PowerSelectScreen());
            return;
        }

        while (MENU_KEY.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new PowerSelectScreen());
        }

        for (int i = 0; i < ABILITY_KEYS.length; i++) {
            while (ABILITY_KEYS[i].consumeClick()) {
                if (mc.screen == null) useAbility(mc, i);
            }
        }
    }

    private static void useAbility(Minecraft mc, int index) {
        if (selected == null) {
            mc.player.displayClientMessage(Component.literal("§cWähle zuerst eine Kraft! Drücke [" + keyName(MENU_KEY) + "] für das Menü."), true);
            return;
        }
        ElementalPowersMod.Element el = ElementalPowersMod.elements().get(selected);
        if (el == null || index >= el.abilities().size()) return;
        // Befehl ohne führenden Schrägstrich
        mc.player.connection.sendCommand("power " + el.id() + " " + el.abilities().get(index).id());
    }

    private static String keyName(KeyMapping k) {
        return k.getTranslatedKeyMessage().getString();
    }

    // ------------------------------------------------------------------
    // HUD oben links
    // ------------------------------------------------------------------
    private static void renderHud(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        int x = 6, y = 6;
        var font = mc.font;

        if (selected == null) {
            g.fill(x - 3, y - 3, x + 190, y + 24, 0x90000000);
            g.drawString(font, "§6Elemental Powers", x, y, 0xFFFFFFFF, true);
            g.drawString(font, "§e[" + keyName(MENU_KEY) + "] §fKraft wählen", x, y + 11, 0xFFFFFFFF, true);
            return;
        }

        ElementalPowersMod.Element el = ElementalPowersMod.elements().get(selected);
        if (el == null) return;

        int rows = el.abilities().size();
        int lineH = 11;
        int widest = 190;
        g.fill(x - 3, y - 3, x + widest, y + (rows + 2) * lineH + 4, 0x90000000);

        g.drawString(font, "§6Kraft: §e" + el.name(), x, y, 0xFFFFFFFF, true);
        for (int i = 0; i < rows && i < ABILITY_KEYS.length; i++) {
            String line = "§a[" + keyName(ABILITY_KEYS[i]) + "] §f" + el.abilities().get(i).name();
            g.drawString(font, line, x, y + (i + 1) * lineH, 0xFFFFFFFF, true);
        }
        g.drawString(font, "§7[" + keyName(MENU_KEY) + "] Menü", x, y + (rows + 1) * lineH, 0xFFFFFFFF, true);
    }

    // ------------------------------------------------------------------
    // Auswahlmenü
    // ------------------------------------------------------------------
    private static final class PowerSelectScreen extends Screen {
        PowerSelectScreen() {
            super(Component.literal("Elemental Powers"));
        }

        @Override
        protected void init() {
            int left = this.width / 2 - 200;
            int top = this.height / 2 - 80;
            int i = 0;
            for (ElementalPowersMod.Element el : ElementalPowersMod.elements().values()) {
                boolean isSel = el.id().equals(selected);
                String label = (isSel ? "▶ " : "") + el.name();
                this.addRenderableWidget(Button.builder(Component.literal(label), b -> {
                    selected = el.id();
                    this.rebuildWidgets();
                }).bounds(left, top + i * 24, 110, 20).build());
                i++;
            }
            this.addRenderableWidget(Button.builder(Component.literal("Los geht's!"), b -> this.onClose())
                .bounds(this.width / 2 - 60, this.height / 2 + 100, 120, 20).build());
        }

        @Override
        public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            super.render(g, mouseX, mouseY, partialTick);

            g.drawCenteredString(this.font, "§6§lELEMENTAL POWERS", this.width / 2, this.height / 2 - 120, 0xFFFFFFFF);
            g.drawCenteredString(this.font, "§7Wähle deine Kraft", this.width / 2, this.height / 2 - 106, 0xFFFFFFFF);

            int textX = this.width / 2 - 70;
            int textY = this.height / 2 - 80;
            ElementalPowersMod.Element el = selected == null ? null : ElementalPowersMod.elements().get(selected);

            if (el == null) {
                g.drawString(this.font, "§fKlicke links auf eine Kraft.", textX, textY, 0xFFFFFFFF, true);
            } else {
                g.drawString(this.font, "§e" + el.name() + " §7- deine Attacken:", textX, textY, 0xFFFFFFFF, true);
                for (int i = 0; i < el.abilities().size() && i < ABILITY_KEYS.length; i++) {
                    ElementalPowersMod.Ability a = el.abilities().get(i);
                    int ly = textY + 18 + i * 24;
                    g.drawString(this.font, "§a[" + keyName(ABILITY_KEYS[i]) + "] §f" + a.name(), textX, ly, 0xFFFFFFFF, true);
                    g.drawString(this.font, "§7" + a.desc(), textX + 10, ly + 10, 0xFFFFFFFF, true);
                }
            }

            g.drawCenteredString(this.font,
                "§7Tasten ändern: Optionen > Steuerung. Menü öffnen: [" + keyName(MENU_KEY) + "]",
                this.width / 2, this.height / 2 + 128, 0xFFFFFFFF);
        }

        @Override
        public boolean isPauseScreen() {
            return false;
        }
    }
}
